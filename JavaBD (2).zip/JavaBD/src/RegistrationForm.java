import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegistrationForm extends JDialog {
    private JTextField tfName;
    private JTextField tfEmail;
    private JTextField tfNumero;
    private JTextField tfEndereco;
    private JPasswordField tfpassword;
    private JPasswordField tfConfirmar;
    private JButton btnRegister;
    private JButton btnCancel;
    private JPanel registerPanel;
    private JLabel password;
    private User user;

    public RegistrationForm(JFrame parent) {
        super(parent);
        setTitle("Crie uma nova conta");

        // Inicializar o painel de registro
        registerPanel = new JPanel();

        // Configurar layout do painel
        registerPanel.setLayout(new GridLayout(7, 2));

        // Criar componentes do formulário
        JLabel lblName = new JLabel("Nome:");
        tfName = new JTextField();

        JLabel lblEmail = new JLabel("Email:");
        tfEmail = new JTextField();

        JLabel lblNumero = new JLabel("Número:");
        tfNumero = new JTextField();

        JLabel lblEndereco = new JLabel("Endereço:");
        tfEndereco = new JTextField();

        JLabel lblpassword = new JLabel("password:");
        tfpassword = new JPasswordField();

        JLabel lblConfirmar = new JLabel("Confirmar password:");
        tfConfirmar = new JPasswordField();

        btnRegister = new JButton("Registrar");
        btnCancel = new JButton("Cancelar");

        // Adicionar componentes ao painel
        registerPanel.add(lblName);
        registerPanel.add(tfName);
        registerPanel.add(lblEmail);
        registerPanel.add(tfEmail);
        registerPanel.add(lblNumero);
        registerPanel.add(tfNumero);
        registerPanel.add(lblEndereco);
        registerPanel.add(tfEndereco);
        registerPanel.add(lblpassword);
        registerPanel.add(tfpassword);
        registerPanel.add(lblConfirmar);
        registerPanel.add(tfConfirmar);
        registerPanel.add(btnRegister);
        registerPanel.add(btnCancel);

        setContentPane(registerPanel);
        setMinimumSize(new Dimension(450, 474));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        btnRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerUser();
            }
        });

        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        setVisible(true);
    }

    private void registerUser() {
        String name = tfName.getText();
        String email = tfEmail.getText();
        String phone = tfNumero.getText();
        String address = tfEndereco.getText();
        String password = new String(tfpassword.getPassword());
        String confirmarpassword = new String(tfConfirmar.getPassword());

        if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || address.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Por favor, preencha todos os campos",
                    "Tente novamente",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!password.equals(confirmarpassword)) {
            JOptionPane.showMessageDialog(this,
                    "As senhas não são iguais.",
                    "Tente novamente",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        User user = addUserToDatabase(name, email, phone, address, password);
        if (user != null) {
            JOptionPane.showMessageDialog(this,
                    "Registro realizado com sucesso",
                    "Sucesso",
                    JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Erro ao registrar um novo usuário",
                    "Tente novamente",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private User addUserToDatabase(String name, String email, String phone, String address, String password) {
        User user = null;
        final String DB_URL = "jdbc:mysql://localhost:3306/javaprojeto";
        final String USERNAME = "root";
        final String PASSWORD = "MySQL@2022";

        try {
            // Registrar o driver JDBC
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Estabelecer a conexão
            Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);

            // Preparar a declaração SQL
            String sql = "INSERT INTO users (name, email, phone, address, password) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, phone);
            statement.setString(4, address);
            statement.setString(5, password);

            // Executar a declaração
            int rowsInserted = statement.executeUpdate();

            if (rowsInserted > 0) {
                user = new User(name, email, phone, address, password);
            }

            // Fechar a declaração e a conexão
            statement.close();
            connection.close();
        } catch (ClassNotFoundException e) {
            System.out.println("Driver JDBC não encontrado");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Erro ao conectar ao banco de dados");
            e.printStackTrace();
        }

        return user;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                RegistrationForm myForm = new RegistrationForm(null);
                User user = myForm.user;
                if (user != null) {
                    System.out.println("Sucesso ao registrar o usuário:");
                    System.out.println("Nome: " + user.getName());
                    System.out.println("Email: " + user.getEmail());
                    System.out.println("Número: " + user.getPhone());
                    System.out.println("Endereço: " + user.getAddress());
                    System.out.println("password: " + user.getPassword());
                } else {
                    System.out.println("Registro cancelado");
                }
            }
        });
    }
}